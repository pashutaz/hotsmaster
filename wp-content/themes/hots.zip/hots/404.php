<?php get_header()?>
        <div class="col-md-9">
            <h1>Ошибка 404</h1>
            <div class="alert alert-danger">Страница не найдена=(</div>
        </div>

        <?php get_template_part('sidebar') ?>

<?php get_footer()?>